package mffs;

import forge.ITextureProvider;
import net.minecraft.server.Item;

public abstract class ItemMFD extends Item implements ITextureProvider
{
    protected int tickcounter = 0;
    protected StringBuffer info = new StringBuffer();
    protected StringBuffer hasher = new StringBuffer();

    public ItemMFD(int var1, int var2)
    {
        super(var1);
        this.e(1);
    }

    public String getTextureFile()
    {
        return "/mffs_grafik/items.png";
    }

    public boolean isRepairable()
    {
        return false;
    }
}
