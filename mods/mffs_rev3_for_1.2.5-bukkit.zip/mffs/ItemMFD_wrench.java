package mffs;

import net.minecraft.server.EntityHuman;
import net.minecraft.server.EntityItem;
import net.minecraft.server.ItemStack;
import net.minecraft.server.World;

public class ItemMFD_wrench extends ItemMFD
{
    public ItemMFD_wrench(int var1)
    {
        super(var1, 0);
        this.d(0);
    }

    /**
     * Callback for item usage. If the item does something special on right clicking, he will have one of those. Return
     * True if something happen and false if it don't. This is for ITEMS, not BLOCKS !
     */
    public boolean interactWith(ItemStack var1, EntityHuman var2, World var3, int var4, int var5, int var6, int var7)
    {
        if (!var3.isStatic && var3.getTileEntity(var4, var5, var6) instanceof TileEntityMaschines)
        {
            TileEntityMaschines var8 = (TileEntityMaschines)var3.getTileEntity(var4, var5, var6);

            if (var8.getWrenchDropRate() > 0.0F)
            {
                if (var8.getFacing() != var7 && var8.getFacing() != -1)
                {
                    var8.setFacing((short)var7);
                    var3.k(var4, var5, var6);
                }
                else
                {
                    ItemStack var9 = new ItemStack(var3.getTypeId(var4, var5, var6), 1, var3.getData(var4, var5, var6));
                    EntityItem var10 = new EntityItem(var3, (double)var4, (double)var5, (double)var6, var9);
                    var3.setTypeId(var4, var5, var6, 0);
                    var3.addEntity(var10);
                }

                return true;
            }
        }

        return false;
    }
}
