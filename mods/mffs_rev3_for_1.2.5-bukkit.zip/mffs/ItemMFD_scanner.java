package mffs;

import net.minecraft.server.Entity;
import net.minecraft.server.ItemStack;
import net.minecraft.server.World;

public class ItemMFD_scanner extends ItemMFD
{
    public ItemMFD_scanner(int var1)
    {
        super(var1, 1);
        this.d(1);
    }

    /**
     * Called each tick as long the item is on a player inventory. Uses by maps to check if is on a player hand and
     * update it's contents.
     */
    public void a(ItemStack var1, World var2, Entity var3, int var4, boolean var5) {}
}
