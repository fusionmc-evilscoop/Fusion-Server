
Forestry uses Java's Properties class to manage language files. These require ISO-8859-1 encoding. UTF-8 is not supported!

If you use a language that requires a different alphabet, do not save to UTF-8, but rather encode it to ISO-8859-1 or convert the UTF-8 file to ISO-8859-1.

If you are unsure / unable to do that, feel free to PM me your translation file on the Minecraft forums at http://minecraftforum.net/ and I will include your translation in the correct encoding with the next release.

You could also try http://www.motobit.com/util/charset-codepage-conversion.asp to convert your file.