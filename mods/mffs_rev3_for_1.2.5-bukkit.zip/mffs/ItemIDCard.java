package mffs;

import forge.ITextureProvider;
import net.minecraft.server.EntityHuman;
import net.minecraft.server.Item;
import net.minecraft.server.ItemStack;
import net.minecraft.server.World;

public class ItemIDCard extends Item implements ITextureProvider
{
    private StringBuffer info = new StringBuffer();

    public ItemIDCard(int var1)
    {
        super(var1);
        this.d(18);
        this.e(1);
    }

    public String getTextureFile()
    {
        return "/mffs_grafik/items.png";
    }

    public boolean isRepairable()
    {
        return false;
    }

    /**
     * Called whenever this item is equipped and the right mouse button is pressed. Args: itemStack, world, entityPlayer
     */
    public ItemStack a(ItemStack var1, World var2, EntityHuman var3)
    {
        if (!var2.isStatic)
        {
            Functions.ChattoPlayer(var3, ":-) Wait for Beta 6");
            Functions.ChattoPlayer(var3, Functions.getTAGfromItemstack(var1).getString("name"));
        }

        return var1;
    }
}
