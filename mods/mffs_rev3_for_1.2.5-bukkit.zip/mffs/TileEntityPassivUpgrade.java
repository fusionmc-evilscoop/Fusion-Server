package mffs;

import net.minecraft.server.NBTTagCompound;
import net.minecraft.server.TileEntity;

public class TileEntityPassivUpgrade extends TileEntityMaschines
{
    private short connectet_typID = 0;
    private int conectet_ID = 0;
    private int counter = 0;

    public int getconectet_ID()
    {
        return this.conectet_ID;
    }

    public void setconectet_ID(int var1)
    {
        this.conectet_ID = var1;
    }

    public short getConnectet_typID()
    {
        return this.connectet_typID;
    }

    public void setConnectet_typID(short var1)
    {
        this.connectet_typID = var1;
    }

    /**
     * Allows the entity to update its state. Overridden in most subclasses, e.g. the mob spawner uses this to count
     * ticks and creates a new spawn inside its implementation.
     */
    public void q_()
    {
        if (!this.world.isStatic)
        {
            if (this.getActive() && this.getWrenchDropRate() != -1.0F)
            {
                this.setWrenchRate(-1.0F);
            }

            if (!this.getActive() && this.getWrenchDropRate() != 1.0F)
            {
                this.setWrenchRate(1.0F);
            }
        }
    }

    public void updatecheck()
    {
        if (!this.world.isStatic && this.conectet_ID != 0)
        {
            switch (this.connectet_typID)
            {
                case 1:
                    TileEntity var1 = (TileEntity)Linkgrid.getWorldMap(this.world).getGenerator().get(Integer.valueOf(this.conectet_ID));

                    if (var1 == null)
                    {
                        this.setconectet_ID(0);
                        this.setActive(false);
                        this.q_();
                    }

                    break;

                case 2:
                    TileEntity var2 = (TileEntity)Linkgrid.getWorldMap(this.world).getProjektor().get(Integer.valueOf(this.conectet_ID));

                    if (var2 == null)
                    {
                        this.setconectet_ID(0);
                        this.setActive(false);
                        this.q_();
                    }
            }
        }
    }

    /**
     * Reads a tile entity from NBT.
     */
    public void a(NBTTagCompound var1)
    {
        super.a(var1);
    }

    /**
     * Writes a tile entity to NBT.
     */
    public void b(NBTTagCompound var1)
    {
        super.b(var1);
    }
}
