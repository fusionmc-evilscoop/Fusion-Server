package mffs;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import net.minecraft.server.World;

public final class Linkgrid
{
    private static Map WorldpowernetMap = new HashMap();

    public static Linkgrid.Worldlinknet getWorldMap(World var0)
    {
        if (var0 != null)
        {
            if (!WorldpowernetMap.containsKey(var0))
            {
                WorldpowernetMap.put(var0, new Linkgrid.Worldlinknet());
            }

            return (Linkgrid.Worldlinknet)WorldpowernetMap.get(var0);
        }
        else
        {
            return null;
        }
    }

    static class Worldlinknet
    {
        private Map Projektor = new Hashtable();
        private Map Generator = new Hashtable();
        private Map RMonitor = new Hashtable();
        public Map RMonitorCount = new Hashtable();

        public Map getProjektor()
        {
            return this.Projektor;
        }

        public Map getGenerator()
        {
            return this.Generator;
        }

        public Map getRMonitor()
        {
            return this.RMonitor;
        }

        public int newGenerator_ID(TileEntityGeneratorCore var1)
        {
            Random var2 = new Random();
            int var3;

            for (var3 = var2.nextInt(); this.Generator.get(Integer.valueOf(var3)) != null; var3 = var2.nextInt())
            {
                ;
            }

            this.Generator.put(Integer.valueOf(var3), var1);
            return var3;
        }

        public int newRMonitor_ID(TileEntityReaktorMonitor var1)
        {
            Random var2 = new Random();
            int var3;

            for (var3 = var2.nextInt(); this.RMonitor.get(Integer.valueOf(var3)) != null; var3 = var2.nextInt())
            {
                ;
            }

            this.RMonitor.put(Integer.valueOf(var3), var1);
            return var3;
        }

        public int newRMonitor_Name(String var1)
        {
            StringBuffer var2 = new StringBuffer();
            int var3;

            for (var3 = myRandom(0, 999); this.RMonitor.get(Integer.valueOf(var3)) != null; var3 = myRandom(0, 999))
            {
                ;
            }

            var2.append(var1);
            var2.append(var3);
            this.RMonitorCount.put(Integer.valueOf(var3), var2.toString());
            return var3;
        }

        public static int myRandom(int var0, int var1)
        {
            return (int)(Math.random() * (double)(var1 - var0) + (double)var0);
        }

        public int conProjektors(int var1, int var2, int var3, int var4, short var5)
        {
            int var6 = 0;
            Iterator var7 = this.Projektor.values().iterator();

            while (var7.hasNext())
            {
                TileEntityProjektor var8 = (TileEntityProjektor)var7.next();

                if (var8.getLinkGenerator_ID() == var1)
                {
                    int var9 = var8.x - var2;
                    int var10 = var8.y - var3;
                    int var11 = var8.z - var4;

                    if ((double)var5 >= Math.sqrt((double)(var9 * var9 + var10 * var10 + var11 * var11)))
                    {
                        ++var6;
                    }
                }
            }

            return var6;
        }
    }
}
