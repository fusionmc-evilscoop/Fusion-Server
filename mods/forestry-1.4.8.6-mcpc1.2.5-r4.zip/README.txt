
Forestry for Minecraft
======================

Please refer to Forestry's thread on the Minecraft forums:
http://www.minecraftforum.net/topic/700588-181-forestry-for-minecraft/page__p__9486882

Forestry Wiki:
http://forestry.sengir.net/wiki/


License:
----------

The code of "Forestry for Minecraft" in source or binary form is the intellectual property of SirSengir.
It may not be reproduced, redistributed or modified. If you have other plans, ask first.

