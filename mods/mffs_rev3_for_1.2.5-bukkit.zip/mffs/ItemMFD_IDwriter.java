package mffs;

import java.util.Iterator;
import java.util.List;
import net.minecraft.server.EntityHuman;
import net.minecraft.server.ItemStack;
import net.minecraft.server.Slot;
import net.minecraft.server.World;
import net.minecraft.server.mod_ModularForceFieldSystem;

public class ItemMFD_IDwriter extends ItemMFD
{
    public ItemMFD_IDwriter(int var1)
    {
        super(var1, 2);
        this.d(2);
    }

    /**
     * Callback for item usage. If the item does something special on right clicking, he will have one of those. Return
     * True if something happen and false if it don't. This is for ITEMS, not BLOCKS !
     */
    public boolean interactWith(ItemStack var1, EntityHuman var2, World var3, int var4, int var5, int var6, int var7)
    {
        return false;
    }

    /**
     * Called whenever this item is equipped and the right mouse button is pressed. Args: itemStack, world, entityPlayer
     */
    public ItemStack a(ItemStack var1, World var2, EntityHuman var3)
    {
        if (!var2.isStatic)
        {
            List var4 = var3.defaultContainer.e;
            Iterator var5 = var4.iterator();

            while (var5.hasNext())
            {
                Slot var6 = (Slot)var5.next();

                if (var6.getItem() != null && var6.getItem().getItem() == mod_ModularForceFieldSystem.MFFSitemcardempty)
                {
                    var6.set(new ItemStack(mod_ModularForceFieldSystem.MFFSitemidc, 1));
                    var6.d();
                    Functions.ChattoPlayer(var3, "[MFD]ID-Card coded");
                    Functions.getTAGfromItemstack(var6.getItem()).setString("name", var3.name);
                    return var1;
                }
            }

            Functions.ChattoPlayer(var3, "[MFD]Error need <MFFS Card blank> in  Inventory");
        }

        return var1;
    }
}
